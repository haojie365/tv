<?php
$id  = isset($_GET['id']) ? intval($_GET['id']) : 0;
$ep  = isset($_GET['ep']) ? intval($_GET['ep']) : 0;

if ($id <= 0) { header('Location: index.php'); exit; }

$page_title = '在线播放';
include 'includes/header.php';
?>

        <div class="container">
            <div class="breadcrumb">
                <a href="index.php"><i class="ri-home-4-line"></i> 首页</a>
                <span class="sep" v-if="vod.type_name">/</span>
                <a v-if="vod.type_name" :href="'list.php?t=' + (vod.type_id || 1)">{{ vod.type_name }}</a>
                <span class="sep">/</span>
                <span class="current">{{ vod.vod_name || '加载中...' }}</span>
            </div>

            <!-- 自建播放器 -->
            <div class="player-wrap" :class="{ 'is-portrait': isPortrait }" ref="playerWrap">
              <div class="vp-inner" @mousemove="!isMobile && showControls()" @mouseleave="!isMobile && hideControlsDelay()">
                <div class="vp-loading" v-if="isLoading">
                    <div class="vp-spinner"></div>
                    <span>加载播放器...</span>
                </div>

                <video ref="videoEl" class="vp-video" :style="videoStyle"
                       @timeupdate="onTimeUpdate" @loadedmetadata="onMeta"
                       @waiting="buffering=true" @canplay="buffering=false"
                       @play="onPlay" @pause="onPause"
                       @ended="onEnded" @volumechange="onVolumeChange"
                       playsinline disablepictureinpicture
                       controlslist="nodownload nofullscreen noremoteplayback"
                       x-webkit-airplay="deny"></video>

                <!-- 点击层：单击控件 双击暂停 长按倍速 -->
                <div class="vp-click-layer"
                     @click.prevent="onVideoClick"
                     @touchstart.passive="onLongPressStart"
                     @touchend.passive="onLongPressEnd"
                     @mousedown.prevent="onLongPressStart"
                     @mouseup="onLongPressEnd"></div>

                <div class="vp-buffering" v-if="buffering && playing">
                    <div class="vp-spinner"></div>
                </div>

                <div class="vp-big-play" v-if="!playing && !isLoading && playUrl" @click.stop="togglePlay">
                    <i class="ri-play-fill"></i>
                </div>

                <!-- 静音提示 -->
                <div class="vp-unmute-tip" v-if="showUnmuteTip" @click.stop="unmute">
                    <i class="ri-volume-up-fill"></i> 点击取消静音
                </div>

                <!-- 长按倍速提示 -->
                <div class="vp-speed-indicator" v-if="isLongPress">
                    <i class="ri-speed-fill"></i> {{ longPressRate }}x 快进中
                </div>

                <div class="player-placeholder" v-if="!isLoading && !playUrl">
                    <i class="ri-play-circle-line"></i>
                    <span>暂无可用播放地址</span>
                </div>

                <!-- 全屏顶部栏：返回+标题 -->
                <div class="vp-top-bar" :class="{ visible: isFullscreen && (controlsVisible || !playing) }" @click.stop>
                    <button class="vp-btn" @click="toggleFullscreen" style="font-size:22px">
                        <i class="ri-arrow-left-line"></i>
                    </button>
                    <div class="vp-top-title">
                        <span>{{ vod.vod_name }}</span>
                        <span v-if="currentEpName" style="opacity:.6;margin-left:6px">{{ currentEpName }}</span>
                    </div>
                </div>

                <!-- 控制栏 -->
                <div class="vp-controls" :class="{ visible: controlsVisible || !playing }" @click.stop @mouseenter="!isMobile && onControlsEnter()" @mouseleave="!isMobile && onControlsLeave()">
                    <div class="vp-progress" ref="progressBar"
                         @mousedown.prevent="startDrag" @touchstart.prevent="startDrag"
                         @mousemove="onProgressHover" @mouseleave="hoverTime=null">
                        <div class="vp-progress-buffered" :style="{ width: bufferedPercent + '%' }"></div>
                        <div class="vp-progress-played" :style="{ width: displayProgress + '%' }"></div>
                        <div class="vp-progress-thumb" :style="{ left: displayProgress + '%' }"></div>
                        <div class="vp-progress-tip" v-if="hoverTime !== null" :style="{ left: hoverPercent + '%' }">{{ formatTime(hoverTime) }}</div>
                    </div>
                    <div class="vp-controls-row">
                        <div class="vp-controls-left">
                            <button class="vp-btn" @click="togglePlay">
                                <i :class="playing ? 'ri-pause-fill' : 'ri-play-fill'"></i>
                            </button>
                            <button class="vp-btn" v-if="epIdx > 0" @click="switchEpisode(epIdx-1)">
                                <i class="ri-skip-back-fill"></i>
                            </button>
                            <button class="vp-btn" v-if="epIdx < maxEp" @click="switchEpisode(epIdx+1)">
                                <i class="ri-skip-forward-fill"></i>
                            </button>
                            <span class="vp-time">{{ formatTime(currentTime) }} / {{ formatTime(duration) }}</span>
                        </div>
                        <div class="vp-controls-right">
                            <div class="vp-menu-wrap">
                                <button class="vp-btn vp-text-btn" @click.stop="toggleMenu('speed')">{{ playbackRate === 1 ? '倍速' : playbackRate + 'x' }}</button>
                                <div class="vp-popup" v-show="activeMenu === 'speed'">
                                    <div class="vp-popup-title">播放速度</div>
                                    <div class="vp-popup-item" v-for="s in speeds" :key="s"
                                         :class="{ active: playbackRate === s }"
                                         @click="setSpeed(s)">{{ s }}x</div>
                                </div>
                            </div>
                            <div class="vp-menu-wrap" v-if="qualities.length > 1">
                                <button class="vp-btn vp-text-btn" @click.stop="toggleMenu('quality')">{{ currentQualityLabel }}</button>
                                <div class="vp-popup" v-show="activeMenu === 'quality'">
                                    <div class="vp-popup-title">清晰度</div>
                                    <div class="vp-popup-item" v-for="q in qualities" :key="q.level"
                                         :class="{ active: currentQuality === q.level }"
                                         @click="setQuality(q.level)">{{ q.label }}</div>
                                </div>
                            </div>
                            <div class="vp-volume-wrap" :class="{ expanded: volOpen }" v-if="!isMobile">
                                <button class="vp-btn" @click="onVolumeClick">
                                    <i :class="volumeIcon"></i>
                                </button>
                                <div class="vp-volume-slider">
                                    <input type="range" min="0" max="1" step="0.05"
                                           :value="muted ? 0 : volume" @input="setVolume" class="vp-vol-range">
                                </div>
                            </div>
                            <div class="vp-menu-wrap" v-if="isFullscreen">
                                <button class="vp-btn" @click.stop="toggleMenu('fit')">
                                    <i class="ri-aspect-ratio-line"></i>
                                </button>
                                <div class="vp-popup" v-show="activeMenu === 'fit'">
                                    <div class="vp-popup-title">画面比例</div>
                                    <div class="vp-popup-item" v-for="f in fitModes" :key="f.value"
                                         :class="{ active: fitMode === f.value }"
                                         @click="setFitMode(f.value)">{{ f.label }}</div>
                                </div>
                            </div>
                            <button class="vp-btn" v-if="isFullscreen" @click="toggleOrientation" :title="isPortrait ? '切换横屏' : '切换竖屏'">
                                <i :class="isPortrait ? 'ri-smartphone-line' : 'ri-tablet-line'"></i>
                            </button>
                            <button class="vp-btn" @click="toggleFullscreen">
                                <i :class="isFullscreen ? 'ri-fullscreen-exit-line' : 'ri-fullscreen-line'"></i>
                            </button>
                        </div>
                    </div>
                </div>
              </div><!-- /vp-inner -->
            </div>

            <!-- 播放信息 -->
            <div class="play-info-bar" v-if="vod.vod_name">
                <div class="play-now-title">
                    <a :href="'detail.php?id=<?php echo $id; ?>'" style="color:inherit;text-decoration:none">{{ vod.vod_name }}</a>
                    <span v-if="currentEpName" style="opacity:.7"> - {{ currentEpName }}</span>
                </div>
                <div class="play-toolbar">
                    <button class="tool-btn" v-if="epIdx > 0" @click="switchEpisode(epIdx-1)">
                        <i class="ri-skip-back-line"></i> 上一集
                    </button>
                    <button class="tool-btn" v-if="epIdx < maxEp" @click="switchEpisode(epIdx+1)">
                        下一集 <i class="ri-skip-forward-line"></i>
                    </button>
                </div>
            </div>

            <!-- 选集 -->
            <div style="margin-bottom:48px;" v-if="episodes.length > 0">
                <h3 class="block-title"><i class="ri-play-list-2-line" style="color:var(--accent)"></i> 选集</h3>
                <div class="ep-grid">
                    <button class="ep-btn"
                       v-for="(e, ei) in episodes"
                       :key="ei"
                       :class="{ active: ei === epIdx }"
                       @click="switchEpisode(ei)">
                        {{ e.name }}
                    </button>
                </div>
            </div>
        </div>

<?php
$vue_script = <<<SCRIPT
<script>
const { createApp } = Vue
createApp({
    data() {
        return {
            vodId: {$id},
            vod: {},
            episodes: [],
            epIdx: {$ep},
            playUrl: '',
            isLoading: true,
            playing: false,
            buffering: false,
            muted: false,
            volume: 1,
            showUnmuteTip: false,
            _isEpSwitch: false,
            currentTime: 0,
            duration: 0,
            bufferedPercent: 0,
            progressPercent: 0,
            dragging: false,
            dragPercent: 0,
            hoverTime: null,
            hoverPercent: 0,
            playbackRate: 1,
            speeds: [0.5, 0.75, 1, 1.25, 1.5, 2, 3],
            qualities: [],
            currentQuality: -1,
            isLongPress: false,
            longPressRate: 3,
            fitMode: 'contain',
            fitModes: [
                { label: '自适应', value: 'contain' },
                { label: '平铺', value: 'cover' },
                { label: '拉伸', value: 'fill' },
                { label: '16:9', value: '16-9' },
                { label: '4:3', value: '4-3' }
            ],
            isFullscreen: false,
            isPortrait: false,
            controlsVisible: true,
            controlsTimer: null,
            activeMenu: null,
            volOpen: false,
            hls: null,
            _tapCount: 0,
            _tapTimer: null,
            _lpTimer: null,
            _wasLongPress: false,
            _savedRate: 1,
            isMobile: ('ontouchstart' in window),
            _controlsHover: false
        }
    },
    computed: {
        currentEpName() { return this.episodes[this.epIdx] ? this.episodes[this.epIdx].name : '' },
        maxEp() { return this.episodes.length - 1 },
        currentQualityLabel() {
            if (this.currentQuality === -1) return '自动'
            const q = this.qualities.find(q => q.level === this.currentQuality)
            return q ? q.label : '自动'
        },
        volumeIcon() {
            if (this.muted || this.volume === 0) return 'ri-volume-mute-fill'
            if (this.volume < 0.5) return 'ri-volume-down-fill'
            return 'ri-volume-up-fill'
        },
        displayProgress() { return this.dragging ? this.dragPercent : this.progressPercent },
        videoStyle() {
            const fm = this.fitMode
            if (fm === 'cover') return { objectFit: 'cover', width: '100%', height: '100%' }
            if (fm === 'fill') return { objectFit: 'fill', width: '100%', height: '100%' }
            if (fm === '16-9') return {
                objectFit: 'contain', inset: 'unset', position: 'absolute',
                top: '50%', left: '50%', transform: 'translate(-50%,-50%)',
                width: 'min(100%, calc(100vh * 16 / 9))',
                height: 'min(100%, calc(100vw * 9 / 16))'
            }
            if (fm === '4-3') return {
                objectFit: 'contain', inset: 'unset', position: 'absolute',
                top: '50%', left: '50%', transform: 'translate(-50%,-50%)',
                width: 'min(100%, calc(100vh * 4 / 3))',
                height: 'min(100%, calc(100vw * 3 / 4))'
            }
            return {}
        }
    },
    mounted() {
        this.fetchDetail()
        document.addEventListener('keydown', this.onKeydown)
        document.addEventListener('click', this.closeMenus)
        document.addEventListener('fullscreenchange', this.onFullscreenChange)
    },
    beforeUnmount() {
        if (this.hls) this.hls.destroy()
        document.removeEventListener('keydown', this.onKeydown)
        document.removeEventListener('click', this.closeMenus)
        document.removeEventListener('fullscreenchange', this.onFullscreenChange)
    },
    methods: {
        parseM3u8Source(playFrom, playUrl) {
            if (!playFrom || !playUrl) return []
            const froms = playFrom.split('\$\$\$')
            const urls = playUrl.split('\$\$\$')
            let m3u8Idx = -1
            for (let i = 0; i < froms.length; i++) {
                if (froms[i].toLowerCase().indexOf('m3u8') !== -1) { m3u8Idx = i; break }
            }
            if (m3u8Idx === -1) m3u8Idx = urls.length - 1
            const raw = (urls[m3u8Idx] || '').trim()
            if (!raw) return []
            return raw.split('#').filter(Boolean).map(part => {
                const [name, link] = part.split('\$', 2)
                return { name, url: link || '' }
            }).filter(e => e.url && e.url.indexOf('.m3u8') !== -1)
        },

        async fetchDetail() {
            try {
                const res = await fetch('api_proxy.php?do=detail&id=' + this.vodId)
                const data = await res.json()
                if (data && data.vod_id) {
                    this.vod = data
                    this.episodes = this.parseM3u8Source(data.vod_play_from || '', data.vod_play_url || '')
                    document.title = data.vod_name + ' - 在线播放 - NewCloud TV'
                    if (this.episodes[this.epIdx]) {
                        this.playUrl = this.episodes[this.epIdx].url
                    }
                }
            } catch(e) {}
            this.isLoading = false
            this.\$nextTick(() => { if (this.playUrl) this.initPlayer() })
        },

        initPlayer() {
            const video = this.\$refs.videoEl
            if (!video || !this.playUrl) return
            if (this.hls) { this.hls.destroy(); this.hls = null }
            video.volume = this.volume
            video.muted = false

            const onReady = () => {
                // Only auto-play if switching episodes (user already interacted)
                if (this._isEpSwitch) {
                    this._isEpSwitch = false
                    video.play().catch(() => {})
                }
            }

            if (Hls.isSupported()) {
                const hls = new Hls({ enableWorker: true, lowLatencyMode: false })
                hls.loadSource(this.playUrl)
                hls.attachMedia(video)
                hls.on(Hls.Events.MANIFEST_PARSED, (evt, data) => {
                    this.qualities = [{ label: '\u81ea\u52a8', level: -1 }]
                    if (data.levels && data.levels.length > 1) {
                        data.levels.forEach((lv, idx) => {
                            let label = lv.height + 'P'
                            if (lv.height >= 2160) label = '4K'
                            else if (lv.height >= 1440) label = '2K'
                            this.qualities.push({ label, level: idx })
                        })
                    }
                    this.currentQuality = -1
                    onReady()
                })
                hls.on(Hls.Events.ERROR, (evt, data) => {
                    if (data.fatal) {
                        if (data.type === Hls.ErrorTypes.NETWORK_ERROR) hls.startLoad()
                        else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) hls.recoverMediaError()
                    }
                })
                this.hls = hls
            } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
                video.src = this.playUrl
                video.addEventListener('loadedmetadata', () => {
                    onReady()
                }, { once: true })
            }
        },

        unmute() {
            const v = this.\$refs.videoEl
            if (v) { v.muted = false; this.muted = false }
            this.showUnmuteTip = false
        },

        // === 单击/双击 ===
        onVideoClick() {
            if (this._wasLongPress) { this._wasLongPress = false; return }
            this._tapCount = (this._tapCount || 0) + 1
            if (this._tapCount === 1) {
                this._tapTimer = setTimeout(() => {
                    if (this._tapCount === 1) {
                        this.controlsVisible = !this.controlsVisible
                        if (this.controlsVisible) {
                            clearTimeout(this.controlsTimer)
                            this.controlsTimer = setTimeout(() => {
                                if (this.playing && !this._controlsHover) this.controlsVisible = false
                            }, 6000)
                        }
                    }
                    this._tapCount = 0
                }, 280)
            } else {
                clearTimeout(this._tapTimer)
                this._tapCount = 0
                this.togglePlay()
            }
        },

        // === 长按倍速 ===
        onLongPressStart(e) {
            if (!this.playing) return
            this._lpTimer = setTimeout(() => {
                this.isLongPress = true
                this._wasLongPress = true
                this._savedRate = this.\$refs.videoEl?.playbackRate || 1
                if (this.\$refs.videoEl) this.\$refs.videoEl.playbackRate = this.longPressRate
            }, 500)
        },
        onLongPressEnd() {
            clearTimeout(this._lpTimer)
            if (this.isLongPress) {
                this.isLongPress = false
                if (this.\$refs.videoEl) this.\$refs.videoEl.playbackRate = this._savedRate
            }
        },

        onPlay() { this.playing = true },
        onPause() { this.playing = false },
        togglePlay() {
            const v = this.\$refs.videoEl
            if (!v) return
            if (this.showUnmuteTip) this.unmute()
            if (v.paused) v.play().catch(() => {})
            else v.pause()
        },

        // === 音量 ===
        onVolumeClick() {
            if (this.isMobile) {
                this.volOpen = !this.volOpen
            } else {
                this.toggleMute()
            }
        },
        toggleMute() {
            const v = this.\$refs.videoEl
            if (!v) return
            v.muted = !v.muted
            this.muted = v.muted
            if (!v.muted && v.volume === 0) { v.volume = 0.5; this.volume = 0.5 }
        },
        setVolume(e) {
            const v = this.\$refs.videoEl
            if (!v) return
            const val = parseFloat(e.target.value)
            v.volume = val; this.volume = val
            v.muted = val === 0; this.muted = val === 0
        },
        onVolumeChange() {
            const v = this.\$refs.videoEl
            if (!v) return
            this.volume = v.volume; this.muted = v.muted
        },

        setSpeed(s) {
            const v = this.\$refs.videoEl
            if (v) v.playbackRate = s
            this.playbackRate = s
            this.activeMenu = null
        },
        setQuality(level) {
            if (this.hls) { this.hls.currentLevel = level; this.currentQuality = level }
            this.activeMenu = null
        },

        // === 全屏 ===
        toggleFullscreen() {
            const wrap = this.\$refs.playerWrap
            if (!wrap) return
            if (document.fullscreenElement) document.exitFullscreen()
            else wrap.requestFullscreen().catch(() => {})
        },
        onFullscreenChange() {
            this.isFullscreen = !!document.fullscreenElement
            if (!this.isFullscreen) {
                this.fitMode = 'contain'
                this.isPortrait = false
                try { screen.orientation.unlock() } catch(e) {}
            }
        },
        setFitMode(mode) { this.fitMode = mode; this.activeMenu = null },
        toggleOrientation() {
            this.isPortrait = !this.isPortrait
            // Try native orientation lock (bonus, not all browsers support)
            try {
                screen.orientation.lock(this.isPortrait ? 'portrait' : 'landscape').catch(() => {})
            } catch(e) {}
        },

        // === 进度条拖拽 ===
        startDrag(e) {
            this.dragging = true
            this.updateDragPos(e)
            document.addEventListener('mousemove', this.onDrag)
            document.addEventListener('mouseup', this.endDrag)
            document.addEventListener('touchmove', this.onDrag, { passive: false })
            document.addEventListener('touchend', this.endDrag)
        },
        onDrag(e) {
            if (!this.dragging) return
            if (e.cancelable) e.preventDefault()
            this.updateDragPos(e)
        },
        endDrag() {
            if (!this.dragging) return
            this.dragging = false
            document.removeEventListener('mousemove', this.onDrag)
            document.removeEventListener('mouseup', this.endDrag)
            document.removeEventListener('touchmove', this.onDrag)
            document.removeEventListener('touchend', this.endDrag)
            const v = this.\$refs.videoEl
            if (v && v.duration) v.currentTime = (this.dragPercent / 100) * v.duration
        },
        updateDragPos(e) {
            const bar = this.\$refs.progressBar
            if (!bar) return
            const rect = bar.getBoundingClientRect()
            const cx = e.touches ? e.touches[0].clientX : e.clientX
            const pct = Math.max(0, Math.min(1, (cx - rect.left) / rect.width))
            this.dragPercent = pct * 100
            const v = this.\$refs.videoEl
            if (v && v.duration) this.currentTime = pct * v.duration
        },
        onProgressHover(e) {
            if (this.dragging) return
            const bar = this.\$refs.progressBar
            const v = this.\$refs.videoEl
            if (!bar || !v || !v.duration) return
            const rect = bar.getBoundingClientRect()
            const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width))
            this.hoverPercent = pct * 100
            this.hoverTime = pct * v.duration
        },
        onTimeUpdate() {
            const v = this.\$refs.videoEl
            if (!v || this.dragging) return
            this.currentTime = v.currentTime
            this.progressPercent = v.duration ? (v.currentTime / v.duration) * 100 : 0
            if (v.buffered.length) {
                this.bufferedPercent = (v.buffered.end(v.buffered.length - 1) / v.duration) * 100
            }
        },
        onMeta() {
            const v = this.\$refs.videoEl
            if (v) this.duration = v.duration
        },

        // === 切集（不刷新页面） ===
        switchEpisode(idx) {
            if (idx < 0 || idx >= this.episodes.length || idx === this.epIdx) return
            this._isEpSwitch = true
            this.epIdx = idx
            this.playUrl = this.episodes[idx].url
            this.currentTime = 0; this.duration = 0
            this.progressPercent = 0; this.bufferedPercent = 0
            history.replaceState(null, '', 'play.php?id=' + this.vodId + '&ep=' + idx)
            document.title = this.vod.vod_name + ' - ' + this.episodes[idx].name + ' - NewCloud TV'
            this.initPlayer()
        },
        onEnded() {
            if (this.epIdx < this.maxEp) {
                this.switchEpisode(this.epIdx + 1)
            }
        },

        toggleMenu(name) { this.activeMenu = this.activeMenu === name ? null : name },
        closeMenus() { this.activeMenu = null; this.volOpen = false },

        onKeydown(e) {
            const v = this.\$refs.videoEl
            if (!v) return
            if (e.key === ' ' || e.key === 'k') { e.preventDefault(); this.togglePlay() }
            if (e.key === 'ArrowLeft')  { e.preventDefault(); v.currentTime = Math.max(0, v.currentTime - 5) }
            if (e.key === 'ArrowRight') { e.preventDefault(); v.currentTime = Math.min(v.duration, v.currentTime + 5) }
            if (e.key === 'ArrowUp')    { e.preventDefault(); v.volume = Math.min(1, v.volume + 0.1) }
            if (e.key === 'ArrowDown')  { e.preventDefault(); v.volume = Math.max(0, v.volume - 0.1) }
            if (e.key === 'f') { e.preventDefault(); this.toggleFullscreen() }
            if (e.key === 'm') { e.preventDefault(); this.toggleMute() }
        },
        onControlsEnter() {
            this._controlsHover = true
            clearTimeout(this.controlsTimer)
            this.controlsVisible = true
        },
        onControlsLeave() {
            this._controlsHover = false
            this.hideControlsDelay()
        },
        showControls() {
            this.controlsVisible = true
            clearTimeout(this.controlsTimer)
            this.controlsTimer = setTimeout(() => { if (this.playing && !this._controlsHover) this.controlsVisible = false }, 4000)
        },
        hideControlsDelay() {
            clearTimeout(this.controlsTimer)
            this.controlsTimer = setTimeout(() => { if (this.playing && !this._controlsHover) this.controlsVisible = false }, 3000)
        },
        formatTime(s) {
            if (!s || isNaN(s)) return '0:00'
            const h = Math.floor(s / 3600)
            const m = Math.floor((s % 3600) / 60)
            const sec = Math.floor(s % 60)
            if (h > 0) return h + ':' + (m < 10 ? '0' : '') + m + ':' + (sec < 10 ? '0' : '') + sec
            return m + ':' + (sec < 10 ? '0' : '') + sec
        }
    }
}).mount('#app')
</script>
SCRIPT;
include 'includes/footer.php';
?>
